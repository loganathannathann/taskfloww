import Common "common";

module {
  public type TaskStatus = {
    #open;
    #completed;
  };

  public type Task = {
    id : Common.TaskId;
    title : Text;
    description : ?Text;
    dueDate : ?Common.Timestamp;
    status : TaskStatus;
    createdAt : Common.Timestamp;
    updatedAt : Common.Timestamp;
  };

  public type CreateTaskInput = {
    title : Text;
    description : ?Text;
    dueDate : ?Common.Timestamp;
  };

  public type UpdateTaskInput = {
    title : ?Text;
    description : ?Text;
    dueDate : ?Common.Timestamp;
    status : ?TaskStatus;
  };
};
