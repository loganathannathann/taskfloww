import List "mo:core/List";
import TaskLib "lib/tasks";
import TaskTypes "types/tasks";
import TasksApi "mixins/tasks-api";
import Migration "migration";

(with migration = Migration.run)
actor {
  let taskStore : TaskLib.TaskStore = List.empty<TaskTypes.Task>();
  let nextTaskId = { var value : Nat = 0 };

  include TasksApi(taskStore, nextTaskId);
};
