import List "mo:core/List";
import Time "mo:core/Time";
import Int "mo:core/Int";
import Common "../types/common";
import Types "../types/tasks";

module {
  public type TaskStore = List.List<Types.Task>;

  public func createTask(
    store : TaskStore,
    nextId : Nat,
    input : Types.CreateTaskInput,
  ) : Types.Task {
    let now = Time.now();
    let task : Types.Task = {
      id = nextId;
      title = input.title;
      description = input.description;
      dueDate = input.dueDate;
      status = #open;
      createdAt = now;
      updatedAt = now;
    };
    store.add(task);
    task;
  };

  public func getAllTasks(store : TaskStore) : [Types.Task] {
    let sorted = store.sort(func(a : Types.Task, b : Types.Task) : { #less; #equal; #greater } {
      Int.compare(b.createdAt, a.createdAt)
    });
    sorted.toArray();
  };

  public func getTask(
    store : TaskStore,
    taskId : Common.TaskId,
  ) : ?Types.Task {
    store.find(func(t : Types.Task) : Bool { t.id == taskId });
  };

  public func updateTask(
    store : TaskStore,
    taskId : Common.TaskId,
    input : Types.UpdateTaskInput,
  ) : ?Types.Task {
    var updated : ?Types.Task = null;
    store.mapInPlace(func(t : Types.Task) : Types.Task {
      if (t.id == taskId) {
        let newTask : Types.Task = {
          t with
          title = switch (input.title) { case (?v) v; case null t.title };
          description = switch (input.description) {
            case (?v) ?v;
            case null t.description;
          };
          dueDate = switch (input.dueDate) {
            case (?v) ?v;
            case null t.dueDate;
          };
          status = switch (input.status) { case (?v) v; case null t.status };
          updatedAt = Time.now();
        };
        updated := ?newTask;
        newTask;
      } else t;
    });
    updated;
  };

  public func deleteTask(
    store : TaskStore,
    taskId : Common.TaskId,
  ) : Bool {
    let sizeBefore = store.size();
    let filtered = store.filter(func(t : Types.Task) : Bool { t.id != taskId });
    let sizeAfter = filtered.size();
    if (sizeAfter < sizeBefore) {
      store.clear();
      store.append(filtered);
      true;
    } else false;
  };

  public func toggleTask(
    store : TaskStore,
    taskId : Common.TaskId,
  ) : ?Types.Task {
    var toggled : ?Types.Task = null;
    store.mapInPlace(func(t : Types.Task) : Types.Task {
      if (t.id == taskId) {
        let newStatus : Types.TaskStatus = switch (t.status) {
          case (#open) #completed;
          case (#completed) #open;
        };
        let newTask : Types.Task = {
          t with
          status = newStatus;
          updatedAt = Time.now();
        };
        toggled := ?newTask;
        newTask;
      } else t;
    });
    toggled;
  };
};
