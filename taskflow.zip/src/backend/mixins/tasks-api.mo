import Common "../types/common";
import Types "../types/tasks";
import TaskLib "../lib/tasks";

mixin (
  store : TaskLib.TaskStore,
  nextTaskId : { var value : Nat },
) {
  public shared func createTask(input : Types.CreateTaskInput) : async Types.Task {
    let id = nextTaskId.value;
    nextTaskId.value += 1;
    TaskLib.createTask(store, id, input);
  };

  public shared query func getTasks() : async [Types.Task] {
    TaskLib.getAllTasks(store);
  };

  public shared query func getTask(taskId : Common.TaskId) : async ?Types.Task {
    TaskLib.getTask(store, taskId);
  };

  public shared func updateTask(taskId : Common.TaskId, input : Types.UpdateTaskInput) : async ?Types.Task {
    TaskLib.updateTask(store, taskId, input);
  };

  public shared func deleteTask(taskId : Common.TaskId) : async Bool {
    TaskLib.deleteTask(store, taskId);
  };

  public shared func toggleTask(taskId : Common.TaskId) : async ?Types.Task {
    TaskLib.toggleTask(store, taskId);
  };
};
