import type { Principal } from "@icp-sdk/core/principal";
export interface Some<T> {
    __kind__: "Some";
    value: T;
}
export interface None {
    __kind__: "None";
}
export type Option<T> = Some<T> | None;
export interface Task {
    id: TaskId;
    status: TaskStatus;
    title: string;
    createdAt: Timestamp;
    dueDate?: Timestamp;
    description?: string;
    updatedAt: Timestamp;
}
export interface CreateTaskInput {
    title: string;
    dueDate?: Timestamp;
    description?: string;
}
export type Timestamp = bigint;
export interface UpdateTaskInput {
    status?: TaskStatus;
    title?: string;
    dueDate?: Timestamp;
    description?: string;
}
export type TaskId = bigint;
export enum TaskStatus {
    open = "open",
    completed = "completed"
}
export interface backendInterface {
    createTask(input: CreateTaskInput): Promise<Task>;
    deleteTask(taskId: TaskId): Promise<boolean>;
    getTask(taskId: TaskId): Promise<Task | null>;
    getTasks(): Promise<Array<Task>>;
    toggleTask(taskId: TaskId): Promise<Task | null>;
    updateTask(taskId: TaskId, input: UpdateTaskInput): Promise<Task | null>;
}
