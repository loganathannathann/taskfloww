import { useActor } from "@caffeineai/core-infrastructure";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { createActor } from "../backend";
import type { CreateTaskInput, TaskId, UpdateTaskInput } from "../types/task";

const TASKS_KEY = ["tasks"] as const;
const POLL_INTERVAL = 5000;

export function useTasksQuery() {
  const { actor, isFetching: actorLoading } = useActor(createActor);

  return useQuery({
    queryKey: TASKS_KEY,
    queryFn: async () => {
      if (!actor) return [];
      return actor.getTasks();
    },
    enabled: !!actor && !actorLoading,
    refetchInterval: POLL_INTERVAL,
    staleTime: 2000,
  });
}

export function useTaskQuery(taskId: TaskId) {
  const { actor, isFetching: actorLoading } = useActor(createActor);

  return useQuery({
    queryKey: ["task", taskId.toString()],
    queryFn: async () => {
      if (!actor) return null;
      return actor.getTask(taskId);
    },
    enabled: !!actor && !actorLoading,
    refetchInterval: POLL_INTERVAL,
  });
}

export function useTaskMutations() {
  const { actor } = useActor(createActor);
  const queryClient = useQueryClient();

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: TASKS_KEY });

  const createTask = useMutation({
    mutationFn: async (input: CreateTaskInput) => {
      if (!actor) throw new Error("Not connected");
      return actor.createTask(input);
    },
    onSuccess: () => {
      toast.success("Task created successfully");
      invalidate();
    },
    onError: () => {
      toast.error("Failed to create task");
    },
  });

  const updateTask = useMutation({
    mutationFn: async ({
      taskId,
      input,
    }: { taskId: TaskId; input: UpdateTaskInput }) => {
      if (!actor) throw new Error("Not connected");
      return actor.updateTask(taskId, input);
    },
    onSuccess: () => {
      toast.success("Task updated");
      invalidate();
    },
    onError: () => {
      toast.error("Failed to update task");
    },
  });

  const deleteTask = useMutation({
    mutationFn: async (taskId: TaskId) => {
      if (!actor) throw new Error("Not connected");
      return actor.deleteTask(taskId);
    },
    onSuccess: () => {
      toast.success("Task deleted");
      invalidate();
    },
    onError: () => {
      toast.error("Failed to delete task");
    },
  });

  const toggleTask = useMutation({
    mutationFn: async (taskId: TaskId) => {
      if (!actor) throw new Error("Not connected");
      return actor.toggleTask(taskId);
    },
    onSuccess: () => {
      invalidate();
    },
    onError: () => {
      toast.error("Failed to update task status");
    },
  });

  return { createTask, updateTask, deleteTask, toggleTask };
}
