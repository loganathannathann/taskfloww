import { ConfirmDialog } from "@/components/ConfirmDialog";
import { Layout } from "@/components/Layout";
import { TaskForm } from "@/components/TaskForm";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { useTaskMutations, useTaskQuery } from "@/hooks/use-tasks";
import { cn } from "@/lib/utils";
import { TaskStatus } from "@/types/task";
import type { UpdateTaskInput } from "@/types/task";
import { useNavigate, useParams } from "@tanstack/react-router";
import {
  ArrowLeft,
  Calendar,
  CheckCircle2,
  Circle,
  Clock,
  Edit2,
  Trash2,
} from "lucide-react";
import { useState } from "react";

function formatDate(ts: bigint): string {
  return new Date(Number(ts) / 1_000_000).toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

function formatDateTime(ts: bigint): string {
  return new Date(Number(ts) / 1_000_000).toLocaleString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function isOverdue(ts: bigint): boolean {
  return Number(ts) / 1_000_000 < Date.now();
}

function isDueSoon(ts: bigint): boolean {
  const ms = Number(ts) / 1_000_000;
  const diff = ms - Date.now();
  return diff > 0 && diff < 3 * 24 * 60 * 60 * 1000;
}

function TaskDetailSkeleton() {
  return (
    <Layout>
      <div
        className="max-w-2xl mx-auto px-4 py-8 space-y-5"
        data-ocid="task_detail.loading_state"
      >
        <Skeleton className="h-8 w-32" />
        <div className="bg-card border border-border rounded-lg p-5 sm:p-6 space-y-4">
          <div className="flex items-start justify-between gap-3">
            <Skeleton className="h-7 w-2/3" />
            <Skeleton className="h-6 w-20" />
          </div>
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
          <Skeleton className="h-4 w-3/4" />
          <Separator />
          <div className="flex gap-4">
            <Skeleton className="h-4 w-28" />
            <Skeleton className="h-4 w-32" />
          </div>
          <Separator />
          <div className="flex gap-2">
            <Skeleton className="h-9 w-36" />
            <Skeleton className="h-9 w-20" />
            <Skeleton className="h-9 w-20" />
          </div>
        </div>
      </div>
    </Layout>
  );
}

function NotFoundState() {
  const navigate = useNavigate();
  return (
    <Layout>
      <div
        className="max-w-2xl mx-auto px-4 py-20 flex flex-col items-center gap-4 text-center"
        data-ocid="task_detail.error_state"
      >
        <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
          <Circle className="h-8 w-8 text-muted-foreground" />
        </div>
        <div className="space-y-1.5">
          <h2 className="text-xl font-display font-semibold text-foreground">
            Task not found
          </h2>
          <p className="text-sm text-muted-foreground max-w-xs">
            This task doesn't exist or may have been deleted.
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => navigate({ to: "/tasks" })}
          data-ocid="task_detail.back_button"
          className="gap-2 mt-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to tasks
        </Button>
      </div>
    </Layout>
  );
}

export function TaskDetailPage() {
  const { taskId } = useParams({ from: "/tasks/$taskId" });
  const navigate = useNavigate();
  const id = BigInt(taskId);

  const { data: task, isLoading } = useTaskQuery(id);
  const { updateTask, deleteTask, toggleTask } = useTaskMutations();

  const [isEditing, setIsEditing] = useState(false);
  const [showDelete, setShowDelete] = useState(false);

  if (isLoading) return <TaskDetailSkeleton />;
  if (!task) return <NotFoundState />;

  const isCompleted = task.status === TaskStatus.completed;

  const handleUpdate = (data: UpdateTaskInput) => {
    updateTask.mutate(
      { taskId: id, input: data },
      { onSuccess: () => setIsEditing(false) },
    );
  };

  const handleDelete = () => {
    deleteTask.mutate(id, {
      onSuccess: () => navigate({ to: "/tasks" }),
    });
  };

  const handleToggle = () => toggleTask.mutate(id);

  return (
    <Layout>
      <div className="max-w-2xl mx-auto px-4 py-8 space-y-5">
        {/* Back button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate({ to: "/tasks" })}
          data-ocid="task_detail.back_button"
          className="gap-2 -ml-2 text-muted-foreground hover:text-foreground transition-colors duration-200"
        >
          <ArrowLeft className="h-4 w-4" />
          All tasks
        </Button>

        {isEditing ? (
          /* ── Inline edit card ── */
          <Card
            className="border-border shadow-xs"
            data-ocid="task_detail.edit.card"
          >
            <CardHeader className="pb-2">
              <h2 className="text-lg font-display font-semibold text-foreground">
                Edit task
              </h2>
            </CardHeader>
            <CardContent>
              <TaskForm
                mode="edit"
                defaultValues={task}
                onSubmit={(d) => handleUpdate(d as UpdateTaskInput)}
                onCancel={() => setIsEditing(false)}
                isPending={updateTask.isPending}
              />
            </CardContent>
          </Card>
        ) : (
          /* ── Read-mode card ── */
          <div
            className="bg-card border border-border rounded-lg p-5 sm:p-6 space-y-5 shadow-xs"
            data-ocid="task_detail.card"
          >
            {/* Title row */}
            <div className="flex items-start gap-3">
              <button
                type="button"
                onClick={handleToggle}
                disabled={toggleTask.isPending}
                data-ocid="task_detail.toggle_button"
                aria-label={isCompleted ? "Mark as open" : "Mark as complete"}
                className="mt-0.5 shrink-0 transition-smooth hover:scale-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-full disabled:opacity-50"
              >
                {isCompleted ? (
                  <CheckCircle2 className="h-6 w-6 text-primary" />
                ) : (
                  <Circle className="h-6 w-6 text-muted-foreground" />
                )}
              </button>

              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <h1
                    className={cn(
                      "font-display text-xl font-bold leading-snug break-words",
                      isCompleted
                        ? "line-through text-muted-foreground"
                        : "text-foreground",
                    )}
                  >
                    {task.title}
                  </h1>
                  <Badge
                    variant="outline"
                    className={cn(
                      "shrink-0 text-xs font-medium",
                      isCompleted
                        ? "bg-muted text-muted-foreground border-muted"
                        : "bg-primary/5 text-primary border-primary/30",
                    )}
                    data-ocid="task_detail.status_badge"
                  >
                    {isCompleted ? "Completed" : "Open"}
                  </Badge>
                </div>
              </div>
            </div>

            {/* Description */}
            {task.description ? (
              <p className="text-sm text-foreground/80 leading-relaxed whitespace-pre-wrap break-words ml-9">
                {task.description}
              </p>
            ) : (
              <p className="text-sm text-muted-foreground/60 italic ml-9">
                No description provided.
              </p>
            )}

            <Separator />

            {/* Metadata */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs text-muted-foreground">
              {task.dueDate && (
                <div className="flex items-center gap-1.5">
                  <Calendar className="h-3.5 w-3.5 shrink-0" />
                  <span
                    className={cn(
                      !isCompleted &&
                        isOverdue(task.dueDate) &&
                        "text-destructive font-semibold",
                      !isCompleted &&
                        isDueSoon(task.dueDate) &&
                        "text-amber-600 font-semibold",
                    )}
                  >
                    Due {formatDate(task.dueDate)}
                    {!isCompleted && isOverdue(task.dueDate) && " · Overdue"}
                    {!isCompleted &&
                      isDueSoon(task.dueDate) &&
                      !isOverdue(task.dueDate) &&
                      " · Due soon"}
                  </span>
                </div>
              )}
              <div className="flex items-center gap-1.5">
                <Clock className="h-3.5 w-3.5 shrink-0" />
                <span>Created {formatDateTime(task.createdAt)}</span>
              </div>
              {task.updatedAt !== task.createdAt && (
                <div className="flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5 shrink-0" />
                  <span>Updated {formatDateTime(task.updatedAt)}</span>
                </div>
              )}
            </div>

            <Separator />

            {/* Action buttons */}
            <div className="flex flex-wrap items-center gap-2">
              <Button
                variant={isCompleted ? "outline" : "default"}
                size="sm"
                onClick={handleToggle}
                disabled={toggleTask.isPending}
                className="font-display font-medium gap-2"
                data-ocid="task_detail.toggle_complete_button"
              >
                {isCompleted ? (
                  <>
                    <Circle className="h-3.5 w-3.5" />
                    Mark as open
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Mark as complete
                  </>
                )}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditing(true)}
                className="gap-1.5"
                data-ocid="task_detail.edit_button"
              >
                <Edit2 className="h-3.5 w-3.5" />
                Edit
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowDelete(true)}
                className="gap-1.5 text-destructive hover:bg-destructive hover:text-destructive-foreground border-destructive/30 transition-colors duration-200"
                data-ocid="task_detail.delete_button"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Delete
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Delete confirm */}
      <ConfirmDialog
        open={showDelete}
        onOpenChange={setShowDelete}
        title="Delete task?"
        description="This task will be permanently deleted and cannot be recovered."
        confirmLabel="Delete task"
        cancelLabel="Cancel"
        onConfirm={handleDelete}
        destructive
      />
    </Layout>
  );
}
