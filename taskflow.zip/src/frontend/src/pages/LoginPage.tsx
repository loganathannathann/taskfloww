import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useNavigate } from "@tanstack/react-router";
import {
  CheckSquare,
  Fingerprint,
  Layers,
  ListChecks,
  Zap,
} from "lucide-react";
import { useEffect } from "react";

const features = [
  { icon: ListChecks, label: "Organize tasks by status" },
  { icon: Zap, label: "Real-time updates via polling" },
  { icon: Layers, label: "Full CRUD with due dates" },
];

export function LoginPage() {
  const { isAuthenticated, isLoading, login } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (isAuthenticated) {
      navigate({ to: "/tasks" });
    }
  }, [isAuthenticated, navigate]);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <div className="flex-1 flex items-center justify-center px-4 py-16">
        <div className="w-full max-w-sm">
          {/* Brand */}
          <div className="flex flex-col items-center text-center mb-10">
            <div className="h-14 w-14 rounded-xl bg-primary flex items-center justify-center mb-4 shadow-xs">
              <CheckSquare
                className="h-7 w-7 text-primary-foreground"
                strokeWidth={2.5}
              />
            </div>
            <h1 className="font-display text-3xl font-bold tracking-tight text-foreground">
              TaskFlow
            </h1>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed max-w-[260px]">
              Stay focused. Track what matters. Ship faster.
            </p>
          </div>

          {/* Feature list */}
          <ul className="space-y-2.5 mb-8">
            {features.map(({ icon: Icon, label }) => (
              <li
                key={label}
                className="flex items-center gap-2.5 text-sm text-muted-foreground"
              >
                <Icon
                  className="h-4 w-4 text-primary shrink-0"
                  strokeWidth={1.75}
                />
                <span>{label}</span>
              </li>
            ))}
          </ul>

          {/* Login card */}
          <div className="bg-card border border-border rounded-lg p-6 shadow-xs">
            <p className="text-xs text-muted-foreground text-center mb-4">
              Sign in securely with your Internet Identity
            </p>
            <Button
              className="w-full gap-2 font-display font-medium"
              size="lg"
              onClick={login}
              disabled={isLoading}
              data-ocid="login.submit_button"
            >
              <Fingerprint className="h-4.5 w-4.5" />
              {isLoading ? "Connecting…" : "Sign in with Internet Identity"}
            </Button>
            <p className="mt-3 text-[11px] text-muted-foreground text-center leading-relaxed">
              No password required. Decentralized auth on the Internet Computer.
            </p>
          </div>
        </div>
      </div>

      <footer className="bg-muted/40 border-t border-border py-4">
        <div className="max-w-3xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-1 text-xs text-muted-foreground">
          <span>Build by Priya L</span>
          <a
            href={`https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(window.location.hostname)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-foreground transition-colors duration-200"
          >
            © {new Date().getFullYear()} Built with love using caffeine.ai
          </a>
        </div>
      </footer>
    </div>
  );
}
