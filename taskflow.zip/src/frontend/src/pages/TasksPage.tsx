import { EmptyState } from "@/components/EmptyState";
import { Layout } from "@/components/Layout";
import { TaskCard } from "@/components/TaskCard";
import { TaskForm } from "@/components/TaskForm";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useTaskMutations, useTasksQuery } from "@/hooks/use-tasks";
import { TaskStatus } from "@/types/task";
import type { CreateTaskInput, TaskFilter } from "@/types/task";
import { Plus, Search } from "lucide-react";
import { useMemo, useState } from "react";

type SortKey = "created" | "due" | "alpha";

export function TasksPage() {
  const { data: tasks = [], isLoading } = useTasksQuery();
  const { createTask } = useTaskMutations();
  const [filter, setFilter] = useState<TaskFilter>("all");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<SortKey>("created");
  const [showCreate, setShowCreate] = useState(false);

  const filtered = useMemo(() => {
    let list = [...tasks];

    if (filter === "open")
      list = list.filter((t) => t.status === TaskStatus.open);
    if (filter === "completed")
      list = list.filter((t) => t.status === TaskStatus.completed);

    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (t) =>
          t.title.toLowerCase().includes(q) ||
          (t.description ?? "").toLowerCase().includes(q),
      );
    }

    if (sort === "created") {
      list.sort((a, b) => Number(b.createdAt - a.createdAt));
    } else if (sort === "due") {
      list.sort((a, b) => {
        const da = a.dueDate ? Number(a.dueDate) : Number.POSITIVE_INFINITY;
        const db = b.dueDate ? Number(b.dueDate) : Number.POSITIVE_INFINITY;
        return da - db;
      });
    } else {
      list.sort((a, b) => a.title.localeCompare(b.title));
    }

    return list;
  }, [tasks, filter, search, sort]);

  const handleCreate = async (data: CreateTaskInput) => {
    await createTask.mutateAsync(data as CreateTaskInput);
    setShowCreate(false);
  };

  const isFiltered = search.trim() !== "" || filter !== "all";

  return (
    <Layout>
      <div className="max-w-3xl mx-auto px-4 py-6">
        {/* Page header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-foreground">
            My Tasks
          </h1>
          <Button
            size="sm"
            onClick={() => setShowCreate(true)}
            className="gap-1.5 font-display font-medium"
            data-ocid="tasks.create_button"
            aria-label="New task"
          >
            <Plus className="h-4 w-4" strokeWidth={2.5} />
            <span className="hidden sm:inline">New task</span>
            <span className="sm:hidden">New</span>
          </Button>
        </div>

        {/* Search + sort + filter bar */}
        <div className="flex flex-col gap-3 mb-5">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
              <Input
                placeholder="Search tasks…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 font-body text-sm"
                data-ocid="tasks.search_input"
              />
            </div>
            <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
              <SelectTrigger
                className="w-[130px] text-xs h-9 font-body shrink-0"
                data-ocid="tasks.sort_select"
              >
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="created" className="text-xs">
                  Date created
                </SelectItem>
                <SelectItem value="due" className="text-xs">
                  Due date
                </SelectItem>
                <SelectItem value="alpha" className="text-xs">
                  Alphabetical
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between gap-3">
            <Tabs
              value={filter}
              onValueChange={(v) => setFilter(v as TaskFilter)}
              data-ocid="tasks.filter.tab"
            >
              <TabsList className="h-8">
                <TabsTrigger
                  value="all"
                  className="text-xs px-3"
                  data-ocid="tasks.filter.all_tab"
                >
                  All
                </TabsTrigger>
                <TabsTrigger
                  value="open"
                  className="text-xs px-3"
                  data-ocid="tasks.filter.open_tab"
                >
                  Open
                </TabsTrigger>
                <TabsTrigger
                  value="completed"
                  className="text-xs px-3"
                  data-ocid="tasks.filter.completed_tab"
                >
                  Done
                </TabsTrigger>
              </TabsList>
            </Tabs>

            {!isLoading && tasks.length > 0 && (
              <span className="text-xs text-muted-foreground shrink-0">
                {filtered.length} of {tasks.length}
              </span>
            )}
          </div>
        </div>

        {/* Task list */}
        {isLoading ? (
          <div className="space-y-3" data-ocid="tasks.loading_state">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-[88px] w-full rounded-lg" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState
            title={isFiltered ? "No matching tasks" : "No tasks yet"}
            description={
              isFiltered
                ? "Try a different search term or filter."
                : "Create your first task to get started."
            }
            actionLabel={!isFiltered ? "Create task" : undefined}
            onAction={!isFiltered ? () => setShowCreate(true) : undefined}
          />
        ) : (
          <div
            className="space-y-3 sm:grid sm:grid-cols-2 lg:grid-cols-3 sm:gap-3 sm:space-y-0"
            data-ocid="tasks.list"
          >
            {filtered.map((task, i) => (
              <TaskCard key={task.id.toString()} task={task} index={i + 1} />
            ))}
          </div>
        )}
      </div>

      {/* Create task dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="sm:max-w-md" data-ocid="tasks.create.dialog">
          <DialogHeader>
            <DialogTitle className="font-display font-semibold">
              New task
            </DialogTitle>
          </DialogHeader>
          <TaskForm
            mode="create"
            onSubmit={(d) => handleCreate(d as CreateTaskInput)}
            onCancel={() => setShowCreate(false)}
            isPending={createTask.isPending}
          />
        </DialogContent>
      </Dialog>
    </Layout>
  );
}
