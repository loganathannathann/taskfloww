import { TaskStatus } from "../backend";
import type {
  CreateTaskInput,
  Task,
  TaskId,
  Timestamp,
  UpdateTaskInput,
} from "../backend";

export type { Task, CreateTaskInput, UpdateTaskInput, TaskId, Timestamp };
export { TaskStatus };

export type TaskFilter = "all" | "open" | "completed";
