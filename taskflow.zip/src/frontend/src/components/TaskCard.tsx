import { Badge } from "@/components/ui/badge";
import { useTaskMutations } from "@/hooks/use-tasks";
import { cn } from "@/lib/utils";
import type { Task } from "@/types/task";
import { TaskStatus } from "@/types/task";
import { useNavigate } from "@tanstack/react-router";
import { Calendar, CheckSquare, Square } from "lucide-react";

interface TaskCardProps {
  task: Task;
  index: number;
}

function formatDueDate(ts: bigint): { label: string; overdue: boolean } {
  const date = new Date(Number(ts) / 1_000_000);
  const now = new Date();
  const overdue = date < now;
  const label = date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  });
  return { label, overdue };
}

export function TaskCard({ task, index }: TaskCardProps) {
  const navigate = useNavigate();
  const { toggleTask } = useTaskMutations();
  const isCompleted = task.status === TaskStatus.completed;

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleTask.mutate(task.id);
  };

  const handleClick = () => {
    navigate({ to: "/tasks/$taskId", params: { taskId: task.id.toString() } });
  };

  const due = task.dueDate ? formatDueDate(task.dueDate) : null;

  return (
    <button
      type="button"
      onClick={handleClick}
      data-ocid={`tasks.item.${index}`}
      className={cn(
        "group w-full text-left bg-card border border-border rounded-lg p-4 cursor-pointer",
        "hover:border-primary/40 hover:shadow-xs transition-smooth",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        isCompleted && "task-card-completed",
      )}
    >
      <div className="flex items-start gap-3">
        <button
          type="button"
          onClick={handleToggle}
          aria-label={isCompleted ? "Mark as open" : "Mark as completed"}
          data-ocid={`tasks.toggle.${index}`}
          className={cn(
            "mt-0.5 shrink-0 h-5 w-5 rounded transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
            isCompleted
              ? "text-primary"
              : "text-muted-foreground hover:text-primary",
          )}
          disabled={toggleTask.isPending}
        >
          {isCompleted ? (
            <CheckSquare className="h-5 w-5" strokeWidth={2} />
          ) : (
            <Square className="h-5 w-5" strokeWidth={1.5} />
          )}
        </button>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 flex-wrap">
            <h3
              className={cn(
                "font-display font-semibold text-sm leading-snug text-foreground break-words",
                isCompleted && "line-through text-muted-foreground",
              )}
            >
              {task.title}
            </h3>
            <Badge
              variant={isCompleted ? "secondary" : "outline"}
              className={cn(
                "shrink-0 text-xs font-medium",
                isCompleted
                  ? "bg-muted text-muted-foreground"
                  : "border-primary/50 text-primary bg-primary/5",
              )}
            >
              {isCompleted ? "Completed" : "Open"}
            </Badge>
          </div>

          {task.description && (
            <p className="mt-1 text-xs text-muted-foreground line-clamp-2 break-words">
              {task.description}
            </p>
          )}

          {due && (
            <div
              className={cn(
                "mt-2 flex items-center gap-1 text-xs",
                due.overdue && !isCompleted
                  ? "text-destructive"
                  : "text-muted-foreground",
              )}
            >
              <Calendar className="h-3.5 w-3.5" />
              <span>{due.label}</span>
            </div>
          )}
        </div>
      </div>
    </button>
  );
}
