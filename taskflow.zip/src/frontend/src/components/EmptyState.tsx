import { Button } from "@/components/ui/button";
import { ClipboardList } from "lucide-react";

interface EmptyStateProps {
  title?: string;
  description?: string;
  actionLabel?: string;
  onAction?: () => void;
}

export function EmptyState({
  title = "No tasks yet",
  description = "Create your first task to get started.",
  actionLabel,
  onAction,
}: EmptyStateProps) {
  return (
    <div
      className="flex flex-col items-center justify-center py-16 px-4 text-center"
      data-ocid="tasks.empty_state"
    >
      <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
        <ClipboardList
          className="h-8 w-8 text-muted-foreground"
          strokeWidth={1.5}
        />
      </div>
      <h3 className="font-display font-semibold text-base text-foreground mb-1">
        {title}
      </h3>
      <p className="text-sm text-muted-foreground max-w-xs mb-5">
        {description}
      </p>
      {actionLabel && onAction && (
        <Button
          size="sm"
          onClick={onAction}
          data-ocid="tasks.empty_state_cta_button"
        >
          {actionLabel}
        </Button>
      )}
    </div>
  );
}
