import { cn } from "@/lib/utils";

interface LoadingSpinnerProps {
  className?: string;
  size?: "sm" | "md" | "lg";
}

const sizeMap = {
  sm: "h-4 w-4 border-2",
  md: "h-7 w-7 border-2",
  lg: "h-10 w-10 border-[3px]",
};

export function LoadingSpinner({
  className,
  size = "md",
}: LoadingSpinnerProps) {
  return (
    <span
      role="status"
      aria-label="Loading"
      data-ocid="loading_state"
      className={cn(
        "inline-block rounded-full border-primary/30 border-t-primary animate-spin",
        sizeMap[size],
        className,
      )}
    />
  );
}

export function PageLoader() {
  return (
    <div
      className="flex-1 flex items-center justify-center min-h-[50vh]"
      data-ocid="page.loading_state"
    >
      <LoadingSpinner size="lg" />
    </div>
  );
}
