import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import type { CreateTaskInput, Task, UpdateTaskInput } from "@/types/task";
import { TaskStatus } from "@/types/task";
import { useForm } from "react-hook-form";

type FormValues = {
  title: string;
  description: string;
  dueDate: string;
};

interface TaskFormProps {
  defaultValues?: Task;
  onSubmit: (data: CreateTaskInput | UpdateTaskInput) => void;
  onCancel: () => void;
  isPending?: boolean;
  mode?: "create" | "edit";
}

export function TaskForm({
  defaultValues,
  onSubmit,
  onCancel,
  isPending,
  mode = "create",
}: TaskFormProps) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormValues>({
    defaultValues: {
      title: defaultValues?.title ?? "",
      description: defaultValues?.description ?? "",
      dueDate: defaultValues?.dueDate
        ? new Date(Number(defaultValues.dueDate) / 1_000_000)
            .toISOString()
            .slice(0, 10)
        : "",
    },
  });

  const handleFormSubmit = (values: FormValues) => {
    const dueDate = values.dueDate
      ? BigInt(new Date(values.dueDate).getTime()) * 1_000_000n
      : undefined;

    if (mode === "create") {
      onSubmit({
        title: values.title.trim(),
        description: values.description.trim() || undefined,
        dueDate,
      } satisfies CreateTaskInput);
    } else {
      const payload: UpdateTaskInput = {
        title: values.title.trim(),
        description: values.description.trim() || undefined,
        dueDate,
        status:
          defaultValues?.status === TaskStatus.completed
            ? TaskStatus.completed
            : TaskStatus.open,
      };
      onSubmit(payload);
    }
  };

  return (
    <form
      onSubmit={handleSubmit(handleFormSubmit)}
      className="space-y-4"
      noValidate
    >
      <div className="space-y-1.5">
        <Label htmlFor="task-title" className="text-sm font-medium">
          Title <span className="text-destructive">*</span>
        </Label>
        <Input
          id="task-title"
          placeholder="e.g. Review pull request"
          data-ocid="task_form.title_input"
          {...register("title", { required: "Title is required" })}
          aria-invalid={!!errors.title}
          className="font-body"
        />
        {errors.title && (
          <p
            className="text-xs text-destructive mt-1"
            data-ocid="task_form.title_field_error"
          >
            {errors.title.message}
          </p>
        )}
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="task-description" className="text-sm font-medium">
          Description{" "}
          <span className="text-muted-foreground font-normal">(optional)</span>
        </Label>
        <Textarea
          id="task-description"
          placeholder="Add context, notes, or subtasks…"
          rows={3}
          data-ocid="task_form.description_textarea"
          {...register("description")}
          className="resize-none font-body text-sm"
        />
      </div>

      <div className="space-y-1.5">
        <Label htmlFor="task-due" className="text-sm font-medium">
          Due date{" "}
          <span className="text-muted-foreground font-normal">(optional)</span>
        </Label>
        <Input
          id="task-due"
          type="date"
          data-ocid="task_form.due_date_input"
          {...register("dueDate")}
          className="font-mono text-sm"
        />
      </div>

      <div className="flex items-center justify-end gap-2 pt-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={onCancel}
          data-ocid="task_form.cancel_button"
        >
          Cancel
        </Button>
        <Button
          type="submit"
          size="sm"
          disabled={isPending}
          data-ocid="task_form.submit_button"
        >
          {isPending
            ? "Saving…"
            : mode === "create"
              ? "Create task"
              : "Save changes"}
        </Button>
      </div>
    </form>
  );
}
