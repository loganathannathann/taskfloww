import { Toaster } from "@/components/ui/sonner";
import { Link } from "@tanstack/react-router";
import { CheckSquare } from "lucide-react";

interface LayoutProps {
  children: React.ReactNode;
  showHeader?: boolean;
}

export function Layout({ children, showHeader = true }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      {showHeader && (
        <header className="sticky top-0 z-40 bg-card border-b border-border shadow-xs">
          <div className="max-w-3xl mx-auto px-4 h-14 flex items-center">
            <Link
              to="/tasks"
              className="flex items-center gap-2 font-display font-semibold text-foreground hover:text-primary transition-colors duration-200"
              data-ocid="nav.home_link"
            >
              <CheckSquare className="h-5 w-5 text-primary" strokeWidth={2.5} />
              <span className="text-lg tracking-tight">TaskFlow</span>
            </Link>
          </div>
        </header>
      )}

      <main className="flex-1 bg-background">{children}</main>

      <footer className="bg-muted/40 border-t border-border py-4">
        <div className="max-w-3xl mx-auto px-4 flex items-center justify-center text-xs text-muted-foreground">
          <span>Build by Priya L</span>
        </div>
      </footer>

      <Toaster richColors position="top-right" />
    </div>
  );
}
