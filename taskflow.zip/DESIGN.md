# Design Brief

**Purpose**: Task management app for creating, tracking, and completing tasks. Light-first, mobile-responsive, typography-driven.

**Tone**: Modern, utilitarian, refined. Inspired by Linear, Notion (minimal mode), Vercel. Every pixel serves function.

**Differentiation**: Card-based task list with single-click completion. Status badges (Open/Completed). Clean typography hierarchy. No decoration—pure functional elegance.

## Palette

| Token              | Light OKLCH              | Dark OKLCH               | Usage                        |
| ------------------ | ------------------------ | ------------------------ | ---------------------------- |
| **Primary**        | `0.52 0.15 201` (Blue)   | `0.7 0.13 196`           | Buttons, links, accents      |
| **Secondary**      | `0.95 0 0` (Off-white)   | `0.18 0 0` (Dark gray)   | Secondary backgrounds        |
| **Destructive**    | `0.6 0.19 28` (Red)      | `0.65 0.19 22`           | Delete, cancel actions       |
| **Success**        | Task completed badge     | Task completed badge     | Completion state             |
| **Muted**          | `0.93 0 0` (Light gray)  | `0.18 0 0` (Dark gray)   | Disabled, secondary text     |
| **Border**         | `0.91 0 0` (Light)       | `0.24 0 0` (Dark)        | Card borders, dividers       |

## Typography

| Layer       | Font               | Size / Weight | Usage              |
| ----------- | ------------------ | ------------- | ------------------ |
| **Display** | Space Grotesk      | 28px / 600    | Page headers       |
| **Body**    | Nunito             | 14px / 400    | Task titles, text  |
| **Mono**    | JetBrains Mono     | 12px / 400    | Timestamps, IDs    |

## Structural Zones

| Zone        | Background         | Border          | Notes                           |
| ----------- | ------------------ | --------------- | ------------------------------- |
| **Header** | `bg-background`    | `border-b`      | Sticky, contains "Tasks" title  |
| **Content**| `bg-background`    | None            | Main task grid/list             |
| **Footer** | `bg-muted/40`      | `border-t`      | Attribution to Priya L          |
| **Card**    | `bg-card`          | `border`        | Task items with subtle shadow   |

## Component Patterns

- **Task Card**: Checkbox + title + description + due date + status badge. Completed tasks rendered at `opacity-60`.
- **Status Badge**: Small inline badge—Open (blue) or Completed (green). Minimal radius (`rounded-sm`).
- **Buttons**: Primary (teal fill), Secondary (gray outline), Destructive (red).
- **Forms**: Input fields with light borders, focus ring in primary color.
- **Toast**: Success/error notifications with dismiss.

## Motion

- **Transitions**: `transition-smooth` (0.3s ease) on hover, focus, state changes.
- **Completion Toggle**: Instant state update + fade to muted opacity.
- **Toast**: Slide in from top, fade out after 3s.

## Shape Language

- **Border Radius**: Minimal (`rounded-sm: 4px`, `rounded-md: 6px`) for utilitarian feel.
- **Spacing**: 4px grid (tight, dense information layout for productivity).
- **Shadows**: Subtle (xs: 0 1px 2px rgba(0,0,0,0.05)) for card elevation.

## Constraints

- Mobile-first responsive (sm, md, lg breakpoints).
- High contrast for accessibility (AA+ compliance).
- No decorative gradients or animations.
- Typography-heavy hierarchy.

## Signature Detail

Single-click task completion toggle—visual state shift from full opacity to muted (60%) without page reload. Instant feedback without modal friction.
